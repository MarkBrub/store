import { ProductDetails } from './productDetails'

function App() {
  return (
      <div className="App">
          <ProductDetails></ProductDetails>
    </div>
  );
}

export default App;
