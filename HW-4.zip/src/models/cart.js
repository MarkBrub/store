export class Cart {
    constructor() {
        this.items = [];
        this.total = 0;
    }
}